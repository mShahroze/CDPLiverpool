<?php

include_once BRUNN_CORE_CPT_PATH . '/masonry-gallery/masonry-gallery-register.php';
include_once BRUNN_CORE_CPT_PATH . '/masonry-gallery/helper-functions.php';