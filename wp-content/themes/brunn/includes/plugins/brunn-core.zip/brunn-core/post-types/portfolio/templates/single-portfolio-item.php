<?php

get_header();

brunn_select_get_title();

do_action('brunn_select_action_before_main_content');

brunn_core_get_single_portfolio();

get_footer();