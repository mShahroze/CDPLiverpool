<?php if($query_results->max_num_pages > 1) { ?>
	<div class="qodef-pl-loading">
		<div class="qodef-brunn-spinner-holder">
			<div class="qodef-brunn-spinner">
				<div></div>
			</div>
		</div>
	</div>
<?php }