<?php

include_once BRUNN_CORE_SHORTCODES_PATH . '/divided-holder/functions.php';
include_once BRUNN_CORE_SHORTCODES_PATH . '/divided-holder/divided-holder.php';