<?php

include_once BRUNN_CORE_SHORTCODES_PATH.'/vertical-showcase/functions.php';
include_once BRUNN_CORE_SHORTCODES_PATH.'/vertical-showcase/vertical-showcase.php';