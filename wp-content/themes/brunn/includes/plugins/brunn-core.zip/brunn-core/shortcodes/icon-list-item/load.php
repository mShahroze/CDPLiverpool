<?php

include_once BRUNN_CORE_SHORTCODES_PATH . '/icon-list-item/functions.php';
include_once BRUNN_CORE_SHORTCODES_PATH . '/icon-list-item/icon-list-item.php';